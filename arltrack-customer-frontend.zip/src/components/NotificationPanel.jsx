import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { db } from "../firebase";
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  updateDoc,
  deleteDoc,
} from "firebase/firestore";

/* ── Icons ── */
const BellIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
  </svg>
);

const XIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

/* ── Helpers ── */
const timeAgo = (ts) => {
  if (!ts) return "";
  let date;
  if (typeof ts?.toDate === "function") date = ts.toDate();
  else if (ts?._seconds !== undefined) date = new Date(ts._seconds * 1000);
  else date = new Date(ts);
  const diff = Math.floor((Date.now() - date.getTime()) / 1000);
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
};

// Every booking-related notification type the customer backend/admin
// backend write into the shared "notifications" collection (see
// customer-backend's models/notification/notification.model.js for the
// full list + which flow creates each one). `badge` drives the status
// pill shown on each card, `action` drives the CTA button — both are
// exactly what the customer needs to know: what happened, and what (if
// anything) they should do next.
const META_BY_TYPE = {
  booking_created: {
    bg: "bg-teal-100", title: "Booking Created",
    badge: { text: "Created", className: "bg-teal-50 text-teal-700" },
    action: "View Booking",
  },
  payment_pending: {
    bg: "bg-amber-100", title: "Payment Pending",
    badge: { text: "Awaiting Payment", className: "bg-amber-50 text-amber-700" },
    action: "Pay Now",
  },
  payment_successful: {
    bg: "bg-green-100", title: "Payment Successful",
    badge: { text: "Paid", className: "bg-green-50 text-green-700" },
    action: "View Details",
  },
  payment_failed: {
    bg: "bg-red-100", title: "Payment Failed",
    badge: { text: "Failed", className: "bg-red-50 text-red-700" },
    action: "Try Again",
  },
  booking_confirmed: {
    bg: "bg-blue-100", title: "Booking Confirmed",
    badge: { text: "Confirmed", className: "bg-blue-50 text-blue-700" },
    action: "View Booking",
  },
  upcoming_booking: {
    bg: "bg-indigo-100", title: "Upcoming Booking",
    badge: { text: "Upcoming", className: "bg-indigo-50 text-indigo-700" },
    action: "View Booking",
  },
  booking_reminder: {
    bg: "bg-indigo-100", title: "Booking Reminder",
    badge: { text: "Starting Soon", className: "bg-indigo-50 text-indigo-700" },
    action: "View Booking",
  },
  booking_cancelled: {
    bg: "bg-gray-200", title: "Booking Cancelled",
    badge: { text: "Cancelled", className: "bg-gray-100 text-gray-600" },
    action: "View Details",
  },
  booking_expired: {
    bg: "bg-orange-100", title: "Booking Expired",
    badge: { text: "Expired", className: "bg-orange-50 text-orange-700" },
    action: "View Details",
  },
  booking_rescheduled: {
    bg: "bg-purple-100", title: "Booking Rescheduled",
    badge: { text: "Rescheduled", className: "bg-purple-50 text-purple-700" },
    action: "View Booking",
  },
  refund_approved: {
    bg: "bg-emerald-100", title: "Refund Approved",
    badge: { text: "Refund Approved", className: "bg-emerald-50 text-emerald-700" },
    action: "View Details",
  },
  refund_rejected: {
    bg: "bg-red-100", title: "Refund Rejected",
    badge: { text: "Refund Rejected", className: "bg-red-50 text-red-700" },
    action: "View Details",
  },
  refund_completed: {
    bg: "bg-emerald-100", title: "Refund Completed",
    badge: { text: "Refunded", className: "bg-emerald-50 text-emerald-700" },
    action: "View Details",
  },
  refund_failed: {
    bg: "bg-red-100", title: "Refund Failed",
    badge: { text: "Refund Failed", className: "bg-red-50 text-red-700" },
    action: "View Details",
  },
  // Written by the ADMIN app when staff record / update a traffic notice or check a handover
  // (refID = the bookingID, so tapping the card opens that booking's details, where the notice
  // and the handover are shown). Contract: customer backend docs/violations-and-handover-contract.md
  violation_recorded: {
    bg: "bg-red-100", title: "Traffic Notice Recorded",
    badge: { text: "Notice", className: "bg-red-50 text-red-700" },
    action: "View Booking",
  },
  handover_verified: {
    bg: "bg-green-100", title: "Handover Checked",
    badge: { text: "Verified", className: "bg-green-50 text-green-700" },
    action: "View Booking",
  },
  discount_applied: {
    bg: "bg-pink-100", title: "Discount Applied",
    badge: { text: "Discount", className: "bg-pink-50 text-pink-700" },
    action: "View Details",
  },
  // Written by the admin app's penalty.service.js (notifyCustomer). The
  // action lands on BookingDetails, whose "Security Deposit & Penalties"
  // card lists each charge, what was deducted and what comes back.
  PenaltyConfirmed: {
    bg: "bg-red-100", title: "Penalty Added",
    badge: { text: "Penalty", className: "bg-red-50 text-red-700" },
    action: "View Breakdown",
  },
  PenaltyWaived: {
    bg: "bg-emerald-100", title: "Penalty Waived",
    badge: { text: "Waived", className: "bg-emerald-50 text-emerald-700" },
    action: "View Details",
  },
  PenaltyVoided: {
    bg: "bg-gray-200", title: "Penalty Removed",
    badge: { text: "Removed", className: "bg-gray-100 text-gray-600" },
    action: "View Details",
  },
  // Written by the ADMIN app (services/terms/terms.service.js → notifyAllUsers) to every
  // user when a new Terms & Conditions version is published. refID is the new termsVersionID,
  // but tapping it opens the CURRENT terms page, not a booking (see handleAction).
  terms_updated: {
    bg: "bg-blue-100", title: "Terms & Conditions Updated",
    badge: { text: "Updated", className: "bg-blue-50 text-blue-700" },
    action: "View Terms",
  },
};

const DEFAULT_META = {
  bg: "bg-gray-100", title: "Notification",
  badge: { text: "Update", className: "bg-gray-100 text-gray-600" },
  action: "View Details",
};

/* ── Notification Row ── */
function NotifRow({ n, onAction, onDelete }) {
  const meta = META_BY_TYPE[n.type] || { ...DEFAULT_META, title: n.title || DEFAULT_META.title };

  // Whole row is clickable now (was: a separate "View Booking/Details →"
  // link at the bottom of each card) — same onAction(n) navigation, just
  // triggered by tapping anywhere on the card. Only clickable when there's
  // actually something to navigate to (n.refID); the dismiss (X) button
  // stops propagation so dismissing never also triggers navigation.
  const clickable = !!n.refID;

  return (
    <div
      onClick={clickable ? () => onAction(n) : undefined}
      className={`flex items-start gap-3 px-5 py-3.5 hover:bg-arl-light/60 transition-colors group ${clickable ? "cursor-pointer" : ""}`}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-sm font-semibold text-arl-dark leading-snug">{meta.title}</p>
          <span className={`text-[10px] font-bold uppercase tracking-wide px-2 py-0.5 rounded-full ${meta.badge.className}`}>
            {meta.badge.text}
          </span>
        </div>
        <p className="text-xs text-gray-500 mt-1 leading-relaxed">{n.message}</p>
        <p className="text-xs text-gray-400 mt-2">{timeAgo(n.createdAt)}</p>
      </div>

      <button
        onClick={(e) => { e.stopPropagation(); onDelete(n.id); }}
        className="opacity-60 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity text-gray-300 hover:text-red-500 active:text-red-500 p-1.5 -m-1 shrink-0"
        title="Dismiss"
      >
        <XIcon />
      </button>
    </div>
  );
}

/* ── Notification Dropdown ── */
function NotificationDropdown({ notifications, onAction, onDelete, onClose }) {
  return (
    <>
      {/* Mobile-only dim backdrop so the sheet reads as a distinct layer
          and gives an obvious, large tap target to dismiss. Hidden on
          sm+ where the panel is a small anchored dropdown instead. */}
      <div
        className="fixed inset-0 z-40 bg-black/20 sm:hidden"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Mobile: fixed sheet pinned to the viewport (with side margins)
          so its width/position never depends on where the bell sits in
          the header — that's what was pushing it off-screen before.
          sm+: original small dropdown anchored under the bell. */}
      <div
        className="fixed left-3 right-3 top-[72px] z-50
                   sm:absolute sm:inset-auto sm:left-auto sm:right-0 sm:top-full sm:mt-2
                   sm:w-96 sm:max-w-[92vw]
                   bg-white rounded-2xl shadow-card border border-gray-100 overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 py-3 border-b bg-arl-light/50">
          <span className="font-semibold text-arl-dark text-sm">Notifications</span>
          <button
            onClick={onClose}
            className="sm:hidden text-gray-400 hover:text-gray-600 p-1 -m-1"
            aria-label="Close notifications"
          >
            <XIcon />
          </button>
        </div>

        <div className="max-h-[65vh] sm:max-h-96 overflow-y-auto divide-y divide-gray-50">
          {notifications.length === 0 ? (
            <div className="py-10 flex flex-col items-center gap-2 text-gray-400">
              <BellIcon />
              <p className="text-sm">No new notifications</p>
            </div>
          ) : (
            notifications.map((n) => (
              <NotifRow key={n.id} n={n} onAction={onAction} onDelete={onDelete} />
            ))
          )}
        </div>

        {notifications.length > 0 && (
          <div className="px-5 py-3 border-t bg-arl-light/50 text-xs text-gray-400 text-center">
            Bookings · Payments · Reminders · Updates
          </div>
        )}
      </div>
    </>
  );
}

/* ── Main Notification Panel ── */
export default function NotificationPanel({ user }) {
  const navigate = useNavigate();
  const [notifOpen, setNotifOpen]         = useState(false);
  const [notifications, setNotifications] = useState([]);
  const notifRef = useRef(null);

  // Live listener, scoped to this customer's own userID — mirrors the
  // admin bell's own query in Header.jsx one-for-one, just pointed at the
  // customer's booking-related types instead of staff-facing ones.
  useEffect(() => {
    if (!user?.userID) {
      setNotifications([]);
      return;
    }

    const unsub = onSnapshot(
      query(
        collection(db, "notifications"),
        where("status", "==", "active"),
        where("userID", "==", user.userID)
      ),
      (snap) => {
        const rows = snap.docs
          .map((d) => ({ id: d.id, ...d.data() }))
          .sort((a, b) => (b.createdAt?.seconds ?? 0) - (a.createdAt?.seconds ?? 0));
        setNotifications(rows);
      }
    );

    return () => unsub();
  }, [user?.userID]);

  // Close on outside click
  useEffect(() => {
    const handleClick = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  if (!user?.userID) return null;

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const hasNew      = unreadCount > 0;

  const handleBellClick = () => {
    const opening = !notifOpen;
    setNotifOpen(opening);
    if (opening) {
      // Mark all currently loaded notifications as read in Firestore (not
      // localStorage) so the badge is consistent across devices/browsers.
      notifications.forEach((n) => {
        if (!n.isRead) {
          updateDoc(doc(db, "notifications", n.id), { isRead: true }).catch(() => {});
        }
      });
    }
  };

  // Every current notification type points at the same place: the
  // booking's own details page, where "Pay Now" already lives as a real
  // link (see BookingDetails.jsx) once a checkout session exists.
  //
  // Exception: a Terms & Conditions update isn't about a booking — it opens the
  // current Terms page. No ?v= on purpose: /terms?v=<id> is the "version you accepted"
  // view (with a banner saying so), whereas here the customer should read the NEW terms.
  const handleAction = (n) => {
    setNotifOpen(false);
    if (n.type === "terms_updated") {
      navigate("/terms");
      return;
    }
    if (n.refID) {
      navigate(`/booking/${n.refID}/details`);
    } else {
      navigate("/my-bookings");
    }
  };

  const handleDelete = (notifID) => {
    deleteDoc(doc(db, "notifications", notifID)).catch(() => {});
  };

  return (
    <div className="relative" ref={notifRef}>
      <button
        onClick={handleBellClick}
        className="relative w-10 h-10 flex items-center justify-center rounded-full bg-white/90 border border-white/40 text-arl-primary hover:bg-arl-light transition-colors"
        aria-label="Notifications"
      >
        <BellIcon />
        {hasNew && (
          <>
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-arl-cta rounded-full animate-ping" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-arl-cta rounded-full" />
            {unreadCount > 1 && (
              <span className="absolute -top-1 -right-1 bg-arl-cta text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </>
        )}
      </button>

      {notifOpen && (
        <NotificationDropdown
          notifications={notifications}
          onAction={handleAction}
          onDelete={handleDelete}
          onClose={() => setNotifOpen(false)}
        />
      )}
    </div>
  );
  
}