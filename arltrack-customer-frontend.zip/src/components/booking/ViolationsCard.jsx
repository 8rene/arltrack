// ViolationsCard.jsx
// Traffic notices that our team has recorded for one booking (read-only). The card hides itself when there
// are none. Staff record each notice and work it through to recovery in the admin app.
import { useCallback, useEffect, useState } from "react";

const API = process.env.REACT_APP_API_URL;
const headers = () => ({ Authorization: `Bearer ${localStorage.getItem("arl_token")}` });
const fmt = (iso) => (iso ? new Date(iso).toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short" }) : "—");
const peso = (v) => `₱${Number(v || 0).toLocaleString()}`;

const STATUS = {
  reported:       ["We're reviewing your report", "bg-amber-50 text-amber-700"], // older notices the renter reported themselves
  recorded:       ["Recorded by our team", "bg-blue-50 text-blue-700"],
  "under review": ["Under review", "bg-amber-50 text-amber-700"],
  contesting:     ["Being contested", "bg-blue-50 text-blue-700"],
  paid:           ["Paid", "bg-green-50 text-green-700"],
  billed:         ["Billed to you", "bg-red-50 text-red-700"],
  recovered:      ["Settled", "bg-green-50 text-green-700"],
  dismissed:      ["Dismissed", "bg-gray-100 text-gray-600"],
};

export default function ViolationsCard({ bookingID }) {
  const [violations, setViolations] = useState([]);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`${API}/violations/booking/${bookingID}`, { headers: headers() });
      if (res.ok) { const d = await res.json(); setViolations(d.violations || []); }
    } catch { /* optional card */ }
  }, [bookingID]);

  useEffect(() => { load(); }, [load]);

  if (violations.length === 0) return null;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <p className="text-xs font-black text-arl-primary uppercase tracking-widest mb-3">Traffic Notices</p>
      <ul className="space-y-2">
        {violations.map((v) => {
          const [label, tone] = STATUS[v.status] || [v.status, "bg-gray-100 text-gray-600"];
          return (
            <li key={v.violationID} className="rounded-xl border border-gray-100 p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <span className="font-semibold text-gray-800">{v.type}</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${tone}`}>{label}</span>
              </div>
              <p className="text-xs text-gray-600">{fmt(v.occurredAt)} · {v.location}</p>
              <p className="text-xs text-gray-500">
                {v.noticeNumber ? `Notice ${v.noticeNumber}` : "No notice number"}{v.amount != null ? ` · ${peso(v.amount)}` : ""}
                {v.contestDeadline ? ` · Contest by ${fmt(v.contestDeadline)}` : ""}
              </p>
            </li>
          );
        })}
      </ul>
    </div>
  );
}