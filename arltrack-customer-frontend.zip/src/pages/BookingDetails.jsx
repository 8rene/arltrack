import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import PenaltyPayButton from "../components/shared/PenaltyPayButton";

// ── Formatting helpers (same conventions as MyBookings.jsx) ──
const fmtDT = (val) => {
  if (!val) return "—";
  if (val?.toDate) return val.toDate().toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  if (val?._seconds !== undefined) return new Date(val._seconds * 1000).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const d = new Date(val);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
};
const peso = (v) => `₱${Number(v || 0).toLocaleString()}`;

const STATUS_STYLE = {
  "to pay":  "bg-yellow-100 text-yellow-700 border-yellow-200",
  upcoming:  "bg-blue-100 text-blue-700 border-blue-200",
  ongoing:   "bg-purple-100 text-purple-700 border-purple-200",
  completed: "bg-green-100 text-green-700 border-green-200",
  cancelled: "bg-red-100 text-red-600 border-red-200",
  pending:   "bg-yellow-100 text-yellow-700 border-yellow-200",
};
const PAYMENT_STYLE = {
  paid:      "bg-green-100 text-green-700 border-green-200",
  pending:   "bg-yellow-100 text-yellow-700 border-yellow-200",
  partial:   "bg-orange-100 text-orange-700 border-orange-200",
  failed:    "bg-red-100 text-red-600 border-red-200",
  cancelled: "bg-gray-100 text-gray-500 border-gray-200",
  refunded:  "bg-blue-100 text-blue-700 border-blue-200",
};

// Same statuses/labels as MyBookings.jsx's RefundStatusBadge, so a booking
// reads consistently whether the customer is looking at the list or this
// details page.
const REFUND_STYLE = {
  Pending:  "bg-yellow-100 text-yellow-700 border-yellow-300",
  Approved: "bg-blue-100 text-blue-700 border-blue-300",
  Refunded: "bg-green-100 text-green-700 border-green-300",
  Rejected: "bg-red-100 text-red-600 border-red-300",
  Failed:   "bg-red-100 text-red-600 border-red-300",
};
const REFUND_LABEL = {
  Pending:  "⏳ Refund: Pending",
  Approved: "🔵 Refund: Approved",
  Refunded: "✅ Refund: Refunded",
  Rejected: "❌ Refund: Rejected",
  Failed:   "❌ Refund: Failed",
};

const Badge = ({ text, styleMap }) => (
  <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold capitalize border ${styleMap[(text || "").toLowerCase()] || "bg-gray-100 text-gray-500 border-gray-200"}`}>
    {text || "—"}
  </span>
);

const DR = ({ label, value, mono = false }) =>
  value ? (
    <div>
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide">{label}</p>
      <p className={`text-sm text-gray-700 font-medium break-all ${mono ? "font-mono" : ""}`}>{value}</p>
    </div>
  ) : null;

// Security deposit + penalties for this booking, in its own card separate
// from Payment Details — a penalty is a deduction against a held deposit,
// not part of the rental transaction, so mixing the two would make Payment
// Details harder to read. Fetches its own data (same non-fatal pattern
// BookingDetailsPage already uses for the refund badge) so a failure here
// never blocks the rest of the page.
//
// Shows, top to bottom: the deposit received, every penalty with what it
// was for, how much of the deposit is deducted for them, and what the
// customer receives back (or still owes). Waived/voided charges stay
// visible but struck-through, since the customer was already notified
// about them. All figures come from the backend (getMyBookingPenalties),
// which mirrors the admin-side settlement math.
const DEPOSIT_BADGE = {
  Refunded:       { label: "Deposit Returned", cls: "bg-green-100 text-green-700 border-green-200" },
  Settled:        { label: "Settled",          cls: "bg-blue-100 text-blue-700 border-blue-200" },
  OwedByCustomer: { label: "Balance Due",      cls: "bg-red-100 text-red-600 border-red-200" },
  Waived:         { label: "Deposit Waived",   cls: "bg-gray-100 text-gray-500 border-gray-200" },
  Held:           { label: "Deposit Held",     cls: "bg-amber-100 text-amber-700 border-amber-200" },
};
const fmtD = (iso) => {
  const d = iso ? new Date(iso) : null;
  return d && !isNaN(d.getTime()) ? d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "";
};

const PenaltyRow = ({ p }) => {
  const removed = p.status !== "Confirmed"; // Waived | Voided
  const fullyPaid = !removed && p.paidAmount >= p.amount;
  const partlyPaid = !removed && p.paidAmount > 0 && !fullyPaid;
  const items = p.lineItems.length ? p.lineItems : [{ description: "Charge", amount: p.amount }];
  return (
    <div className={`rounded-xl border px-3 py-2.5 ${removed ? "border-gray-100 bg-gray-50" : "border-red-100 bg-red-50/40"}`}>
      {items.map((i, idx) => (
        <div key={idx} className="flex items-start justify-between gap-3 text-sm">
          <span className={removed ? "text-gray-400 line-through" : "text-gray-700"}>{i.description}</span>
          <span className={`shrink-0 font-medium ${removed ? "text-gray-400 line-through" : "text-red-500"}`}>-{peso(i.amount)}</span>
        </div>
      ))}
      <div className="flex items-center justify-between mt-1.5 text-[11px] text-gray-400">
        <span>{fmtD(p.createdAt)}</span>
        <span className={fullyPaid ? "text-green-600 font-semibold" : partlyPaid ? "text-amber-600 font-semibold" : removed ? "font-semibold" : ""}>
          {p.status === "Waived" && "Waived — no charge"}
          {p.status === "Voided" && "Removed — no charge"}
          {fullyPaid && "Paid"}
          {partlyPaid && `${peso(p.paidAmount)} paid · ${peso(p.amount - p.paidAmount)} left`}
        </span>
      </div>
    </div>
  );
};

const PenaltiesBox = ({ bookingID }) => {
  const [info, setInfo] = useState(null); // null = loading, false = failed to load
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const token = localStorage.getItem("arl_token");
        const res = await fetch(`${process.env.REACT_APP_API_URL}/bookings/${bookingID}/penalties`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error();
        const json = await res.json();
        if (!cancelled) setInfo(json.data);
      } catch {
        if (!cancelled) setInfo(false);
      }
    })();
    return () => { cancelled = true; };
  }, [bookingID]);

  if (info === null || info === false) return null; // loading or failed — never block the page

  const {
    depositAmount, depositStatus, depositSettled, penalties,
    deductedFromDeposit, refundAmount, refundMethod, refundedAt, stillOwed, settlement,
  } = info;
  const depositWaived = depositStatus === "Waived";
  const hasDeposit = depositAmount !== null && !depositWaived;
  if (depositAmount === null && penalties.length === 0) return null; // nothing to show pre-pickup

  const badgeKey = settlement?.status || (hasDeposit ? "Held" : depositWaived ? "Waived" : null);
  const badge = badgeKey ? DEPOSIT_BADGE[badgeKey] : null;
  const showRefundRow = hasDeposit && (refundAmount > 0 || stillOwed === 0);

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-black text-arl-primary uppercase tracking-widest">🔒 Security Deposit &amp; Penalties</p>
        {badge && <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold border ${badge.cls}`}>{badge.label}</span>}
      </div>

      {/* 1 ── Deposit received */}
      {hasDeposit && (
        <div className="flex items-baseline justify-between mb-3">
          <span className="text-sm text-gray-500">Deposit received</span>
          <span className="text-sm font-semibold text-gray-700">{peso(depositAmount)}</span>
        </div>
      )}
      {depositWaived && <p className="text-sm text-gray-500 mb-3">Your security deposit was waived for this booking.</p>}
      {depositAmount === null && penalties.length > 0 && (
        <p className="text-sm text-gray-500 mb-3">No security deposit was recorded for this booking.</p>
      )}

      {/* 2 ── Penalties, with what each one was for */}
      {penalties.length > 0 && (
        <div className="mb-3">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Penalties</p>
          <div className="space-y-2">{penalties.map((p) => <PenaltyRow key={p.penaltyID} p={p} />)}</div>
        </div>
      )}

      {/* 3 + 4 ── Deducted, then what comes back / what is still owed */}
      {(hasDeposit || stillOwed > 0) && (
        <div className="border-t border-gray-100 pt-3 space-y-2">
          {hasDeposit && penalties.some((p) => p.status === "Confirmed") && (
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-gray-500">{depositSettled ? "Deducted from deposit" : "To be deducted from deposit"}</span>
              <span className="text-sm font-semibold text-red-500">-{peso(deductedFromDeposit)}</span>
            </div>
          )}

          {showRefundRow && (
            <div className="flex items-baseline justify-between">
              <span className="text-sm font-semibold text-gray-700">{depositSettled ? "Deposit returned to you" : "You'll receive back"}</span>
              <span className="text-base font-bold text-green-600">{peso(refundAmount)}</span>
            </div>
          )}
          {depositSettled && refundAmount > 0 && (
            <p className="text-xs text-gray-400">
              Returned{refundMethod ? ` via ${refundMethod}` : ""}{refundedAt ? ` on ${fmtD(refundedAt)}` : ""}.
            </p>
          )}

          {stillOwed > 0 && (
            <>
              <div className="flex items-baseline justify-between">
                <span className="text-sm font-semibold text-gray-700">Balance you owe</span>
                <span className="text-base font-bold text-red-600">{peso(stillOwed)}</span>
              </div>
              <p className="text-xs text-gray-400">
                {hasDeposit && !depositSettled
                  ? "Your deposit doesn't fully cover the penalties. Please settle the remaining balance with our staff."
                  : "Pay it online below, or settle it in store on your next visit."}
              </p>
              {/* Online payment only once the deposit is settled — until then the deposit still covers it. */}
              {(!hasDeposit || depositSettled) && (
                <PenaltyPayButton bookingID={bookingID} amount={stillOwed}
                  className="w-full text-sm font-bold text-white bg-red-600 hover:bg-red-700 px-4 py-2.5 rounded-xl transition" />
              )}
            </>
          )}

          {!depositSettled && hasDeposit && (
            <p className="text-xs text-gray-400">The final amounts are confirmed when the vehicle is returned and the deposit is settled.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default function BookingDetailsPage() {
  const { bookingID } = useParams();
  const navigate = useNavigate();

  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState("");
  // Whichever refund request (any status) exists for this booking's
  // payment — same source/shape as MyBookings.jsx uses, fetched separately
  // since /bookings/:bookingID/details doesn't include refund info.
  const [refund, setRefund]   = useState(null);
  const [payingNow, setPayingNow] = useState(false);
  const [payError, setPayError]   = useState("");
  const [resendingReceipt, setResendingReceipt] = useState(false);
  const [receiptMsg, setReceiptMsg] = useState("");
  // Countdown (seconds) before "Email My Receipt" can be clicked again —
  // set from the server's cooldown so it survives a page refresh, not just
  // local component state.
  const [receiptCooldown, setReceiptCooldown] = useState(0);

  // "Complete Payment" used to open the STORED checkout URL directly. That URL can
  // belong to a session that was already paid (webhook slow) or has expired, so the
  // customer could be sent to a dead page — or pay twice. Going through create-link
  // makes the server ask PayMongo first: already paid → just confirm it; expired →
  // a fresh session; still open → the same link.
  const handleCompletePayment = async () => {
    const pay = data?.payment;
    if (!pay?.paymentID) return;
    setPayingNow(true); setPayError("");
    try {
      const token = localStorage.getItem("arl_token");
      const phase = pay.balanceStatus === "pending" ? "balance" : "deposit";
      const res = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/create-link`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          bookingID,
          paymentID: pay.paymentID,
          description: `ARL Track Booking #${bookingID}${phase === "balance" ? " (Balance)" : ""}`,
          paymentMethod: pay.paymentMethod,
          phase,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.message || "Failed to open payment.");
      if (json.alreadyPaid) { navigate(`/payment-return?paymentID=${pay.paymentID}&bookingID=${bookingID}`); return; }
      window.location.href = json.checkoutUrl + `?paymentID=${pay.paymentID}`;
    } catch (err) {
      setPayError(err.message || "Could not connect to PayMongo. Please try again.");
      setPayingNow(false);
    }
  };

  const RECEIPT_COOLDOWN_SECONDS = 5 * 60;

  const handleResendReceipt = async () => {
    setResendingReceipt(true); setReceiptMsg("");
    try {
      const token = localStorage.getItem("arl_token");
      const res = await fetch(`${process.env.REACT_APP_API_URL}/bookings/${bookingID}/resend-receipt`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json();
      if (!res.ok) {
        if (res.status === 429 && json.retryAfterSeconds) {
          setReceiptCooldown(json.retryAfterSeconds);
        }
        throw new Error(json.message || "Failed to send receipt.");
      }
      setReceiptMsg(json.message || "Receipt sent to your email.");
      setReceiptCooldown(RECEIPT_COOLDOWN_SECONDS);
    } catch (err) {
      setReceiptMsg(err.message || "Could not send the receipt. Please try again.");
    } finally {
      setResendingReceipt(false);
    }
  };

  // Ticks the cooldown down once a second while it's active.
  useEffect(() => {
    if (receiptCooldown <= 0) return;
    const t = setInterval(() => setReceiptCooldown((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [receiptCooldown]);

  useEffect(() => { fetchDetails(); }, [bookingID]);

  const fetchDetails = async () => {
    setLoading(true); setError("");
    try {
      const token = localStorage.getItem("arl_token");
      const res = await fetch(`${process.env.REACT_APP_API_URL}/bookings/${bookingID}/details`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to load booking details.");
      const json = await res.json();
      setData(json);

      // Restore the "Email My Receipt" cooldown across refreshes — the
      // server timestamps the last successful send on the payment doc.
      if (json.payment?.lastReceiptSentAt) {
        const raw = json.payment.lastReceiptSentAt;
        const lastSent = raw?._seconds !== undefined ? new Date(raw._seconds * 1000) : new Date(raw);
        if (!isNaN(lastSent.getTime())) {
          const remaining = RECEIPT_COOLDOWN_SECONDS - Math.floor((Date.now() - lastSent.getTime()) / 1000);
          if (remaining > 0) setReceiptCooldown(remaining);
        }
      }

      if (json.payment?.paymentID) {
        try {
          const rRes = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/refunds/mine`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          if (rRes.ok) {
            const refunds = await rRes.json();
            const match = (Array.isArray(refunds) ? refunds : []).find(
              (r) => r.paymentID === json.payment.paymentID
            );
            setRefund(match || null);
          }
        } catch {
          // Non-fatal — the page still works without the refund badge.
        }
      }
    } catch (err) {
      setError(err.message || "Could not load this booking.");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-24 pb-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3" />
          <div className="h-40 bg-gray-200 rounded-2xl" />
          <div className="h-60 bg-gray-100 rounded-2xl" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-gray-50 pt-24 pb-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center py-20">
          <p className="text-5xl mb-4">🚫</p>
          <p className="text-gray-600 font-semibold">{error || "Booking not found."}</p>
          <button onClick={() => navigate("/my-bookings")}
            className="mt-5 px-6 py-2.5 bg-arl-primary text-white rounded-full text-sm font-bold hover:bg-arl-secondary transition">
            ← Back to My Bookings
          </button>
        </div>
      </div>
    );
  }

  const { booking, pickupLocation, dropoffLocation, payment } = data;
  // pickupLocation/dropoffLocation come back as { address, lat, lng } objects
  // (or null) — never plain strings, so we must pull .address out here
  // rather than handing the whole object to <DR>, which would crash trying
  // to render an object as a React child.
  const pickupAddress  = pickupLocation?.address  || null;
  const dropoffAddress = dropoffLocation?.address || null;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 space-y-4 sm:space-y-6">

        <button onClick={() => navigate(-1)}
          className="text-sm font-semibold text-arl-secondary hover:text-arl-primary transition inline-flex items-center gap-1">
          ← Back
        </button>

        {/* Header card */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="flex gap-4 p-5">
            <div className="w-28 h-20 sm:w-36 sm:h-24 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
              {booking.carImage
                ? <img src={booking.carImage} alt={booking.carName} className="w-full h-full object-cover" />
                : <div className="w-full h-full flex items-center justify-center text-3xl text-gray-300">🚗</div>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2 flex-wrap">
                <div>
                  <h1 className="font-black text-lg sm:text-xl text-arl-primary">{booking.carName || "Unknown Vehicle"}</h1>
                  <p className="text-xs text-gray-400 font-mono mt-0.5">{booking.bookingID}</p>
                </div>
                {/* Header badge priority: a matched refund request's own
                    status (most specific) → the payment's own "refunded"
                    state (covers refunds that didn't go through the
                    customer refund-request flow) → the raw booking status
                    as a last resort, which otherwise stays stuck on
                    "upcoming" forever once refunded. */}
                {refund
                  ? <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold border ${REFUND_STYLE[refund.status] || "bg-gray-100 text-gray-500 border-gray-200"}`}>
                      {REFUND_LABEL[refund.status] || `Refund: ${refund.status}`}
                    </span>
                  : (payment?.status || "").toLowerCase() === "refunded"
                  ? <Badge text="Refunded" styleMap={PAYMENT_STYLE} />
                  : <Badge text={booking.status} styleMap={STATUS_STYLE} />}
              </div>
              {/* Admin's reason for rejecting the refund — already captured
                  and saved on the refundRequests doc (rejectReason), just
                  never displayed anywhere in the customer app before. */}
              {refund?.status === "Rejected" && refund?.rejectReason && (
                <div className="mt-2 flex items-start gap-1.5 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                  <span className="text-red-400 text-xs leading-none mt-0.5">✕</span>
                  <p className="text-xs text-red-600 leading-snug">
                    <span className="font-semibold">Refund rejected:</span> {refund.rejectReason}
                  </p>
                </div>
              )}
              <div className="flex flex-wrap gap-3 mt-2 text-xs text-gray-500">
                {booking.serviceType && <span>{booking.serviceType}</span>}
                <span>{booking.totalDays} day(s)</span>
                <span>{booking.modeOfDriving || "With Chauffeur"}</span>
              </div>
              {payment?.discountAmount > 0 ? (
                <div className="flex items-baseline gap-2 mt-2 flex-wrap">
                  <p className="text-lg font-black text-arl-cta">{peso(booking.totalFee - payment.discountAmount)}</p>
                  <p className="text-sm text-gray-400 line-through">{peso(booking.totalFee)}</p>
                </div>
              ) : (
                <p className="text-lg font-black text-arl-cta mt-2">{peso(booking.totalFee)}</p>
              )}
            </div>
          </div>
        </div>

        {/* Trip details */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
          <p className="text-xs font-black text-arl-primary uppercase tracking-widest mb-3">🗓️ Trip Details</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-3">
            <DR label="Start"          value={fmtDT(booking.startDateTime)} />
            <DR label="End"            value={fmtDT(booking.endDateTime)} />
            <DR label="Days"           value={`${booking.totalDays} day(s)`} />
            <DR label="Service"        value={booking.serviceType} />
            <DR label="Drive Mode"     value={booking.modeOfDriving} />
            <DR label="Pickup"         value={pickupAddress} />
            <DR label="Drop-off"       value={dropoffAddress} />
          </div>
        </div>

        {/* Payment */}
        {payment ? (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-black text-arl-primary uppercase tracking-widest">💳 Payment Details</p>
              <Badge text={payment.status} styleMap={PAYMENT_STYLE} />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-3 mb-4">
              <DR label="Payment ID"        value={payment.paymentID} mono />
              <DR label="Total Amount"      value={peso(payment.amount)} />
              <DR label="Rental Fee"        value={peso(payment.rentalFee)} />
              <DR label={payment.serviceFeeRate > 0 ? `Service Fee (${payment.serviceFeeRate}% of rental)` : "Service Fee"} value={peso(payment.serviceFee)} />
              <DR label={payment.gatewayFeeRate > 0 ? `Gateway Fee (${payment.gatewayFeeRate}% of total)` : "Gateway Fee"} value={peso(payment.gatewayFee)} />
              <DR label="Extra Fee"         value={payment.extraFee ? peso(payment.extraFee) : null} />
              <DR label="Driver's Fee"      value={payment.driversFee ? peso(payment.driversFee) : null} />
              <DR label="Discount Applied"  value={payment.discountAmount ? peso(payment.discountAmount) : null} />
              <DR label="Balance Due"       value={peso(payment.balanceDue)} />
              <DR label="Payment Method"    value={payment.methodOfPayment} />
              <DR label="Reference No."     value={payment.referenceNumber} mono />
            </div>
            {payment.checkoutUrl && (payment.status === "pending" || payment.balanceStatus === "pending") && (
              <>
                <button type="button" onClick={handleCompletePayment} disabled={payingNow}
                  className="inline-block px-5 py-2.5 bg-arl-cta text-white rounded-full text-sm font-bold hover:bg-arl-secondary disabled:opacity-60 transition">
                  {payingNow ? "Opening…" : payment.balanceStatus === "pending" ? "Complete Balance Payment →" : "Complete Payment →"}
                </button>
                {payError && <p className="text-xs text-red-500 mt-2">{payError}</p>}
              </>
            )}
            {payment.status === "paid" && (
              <div className="mt-3">
                <button type="button" onClick={handleResendReceipt} disabled={resendingReceipt || receiptCooldown > 0}
                  className="inline-block px-5 py-2.5 bg-white border border-arl-primary text-arl-primary rounded-full text-sm font-bold hover:bg-arl-primary hover:text-white disabled:opacity-60 transition">
                  {resendingReceipt
                    ? "Sending…"
                    : receiptCooldown > 0
                      ? `📧 Email My Receipt (${Math.floor(receiptCooldown / 60)}:${String(receiptCooldown % 60).padStart(2, "0")})`
                      : "📧 Email My Receipt"}
                </button>
                {receiptMsg && <p className="text-xs text-gray-500 mt-2">{receiptMsg}</p>}
              </div>
            )}
            {payment.proofUrl && (
              <div className="mt-3">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Proof of Payment</p>
                <img src={payment.proofUrl} alt="Payment proof"
                  className="max-h-48 w-auto rounded-xl border border-gray-200 object-contain bg-white"
                  onError={(e) => { e.target.style.display = "none"; }} />
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
            <p className="text-xs text-gray-400">No payment record found for this booking.</p>
          </div>
        )}

        {payment && <PenaltiesBox bookingID={bookingID} />}
      </div>
    </div>
  );
}