import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "../context/ToastContext";
import DiscountSummary, { DiscountHeldPill, discountPriceOff } from "../components/booking/DiscountSummary";

// ── Date formatter — handles Firestore Timestamps, JS Dates, ISO strings ──
const fmtDT = (val) => {
  if (!val) return "—";
  if (val?.toDate) return val.toDate().toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  if (val?._seconds !== undefined) return new Date(val._seconds * 1000).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const d = new Date(val);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" });
};

const peso = (v) => `₱${Number(v || 0).toLocaleString()}`;

// ── Payment status config (badge shown on each booking card) ──
const PAYMENT_STATUS_CONFIG = {
  due:       { label: "Payment Due",       bg: "bg-yellow-100", text: "text-yellow-700", border: "border-yellow-300" },
  partial:   { label: "Partial",           bg: "bg-orange-100", text: "text-orange-700", border: "border-orange-300" },
  paid:      { label: "Fully Paid",        bg: "bg-green-100",  text: "text-green-700",  border: "border-green-300" },
  refunded:  { label: "Refunded",          bg: "bg-blue-100",   text: "text-blue-700",   border: "border-blue-300" },
  failed:    { label: "Payment Failed",    bg: "bg-red-100",    text: "text-red-600",    border: "border-red-300" },
  cancelled: { label: "Payment Cancelled", bg: "bg-gray-100",   text: "text-gray-500",   border: "border-gray-300" },
};

// Mirrors admin's computeAmounts() in payments.service.js, so the customer
// sees the same paid/balance math the admin dashboard uses. Uses the real
// two-phase payment state (status/balanceStatus/payNow — see
// utils/bookings/bookingStatus.util.js on the backend) rather than
// guessing amountPaid purely from methodOfPayment, which used to claim a
// booking was "Partial — balance due" even when the deposit itself hadn't
// actually been paid yet (methodOfPayment is set at booking creation,
// before any charge happens).
const getPaymentInfo = (payment) => {
  if (!payment) return { key: "due", extra: "", amountPaid: 0 };

  // Preferred: the backend's own derivation (getUserBookings → derivePaymentStatus),
  // built on the same shared math the admin dashboard uses — it knows about a
  // balance paid online, one staff collected in person, cash-confirmed payments
  // and staff discounts, none of which this file can see from here. The local
  // logic below is only a fallback for a response that doesn't carry it.
  const derived = payment.paymentStatus;
  if (derived && derived.key) {
    return {
      key: derived.key,
      extra: derived.key === "partial" ? peso(derived.balance) : "",
      amountPaid: Number(derived.amountPaid) || 0,
    };
  }

  const amount = Number(payment.amount) || 0;
  const status = (payment.status || "").toLowerCase();
  const method = (payment.methodOfPayment || "").toLowerCase();

  if (status === "refunded") return { key: "refunded", extra: "", amountPaid: 0 };
  if (status === "failed" || status === "rejected") return { key: "failed", extra: "", amountPaid: 0 };
  if (status === "cancelled") return { key: "cancelled", extra: "", amountPaid: 0 };
  if (status !== "paid" && status !== "approved") return { key: "due", extra: "", amountPaid: 0 }; // deposit not paid yet
  if (payment.balanceCollected) return { key: "paid", extra: "", amountPaid: amount }; // staff collected the rest in person

  if (method.includes("full")) return { key: "paid", extra: "", amountPaid: amount };

  // Partial: deposit has cleared (status === "paid") — the only remaining
  // question is whether the balance phase has cleared too.
  const balanceStatus = (payment.balanceStatus || "").toLowerCase();
  if (balanceStatus === "paid") return { key: "paid", extra: "", amountPaid: amount };

  // payNow is the actual amount charged for the deposit (stored since this
  // two-phase flow was added); Math.floor(amount/2) is only a fallback for
  // any older payment record saved before that field existed.
  const amountPaid = Number(payment.payNow) || Math.floor(amount / 2);
  return { key: "partial", extra: peso(amount - amountPaid), amountPaid };
};

const PaymentStatusBadge = ({ payment }) => {
  const { key, extra } = getPaymentInfo(payment);
  const cfg = PAYMENT_STATUS_CONFIG[key];
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
      {cfg.label}{extra ? ` — ${extra} due` : ""}
    </span>
  );
};

// Balance still owed on a Partial booking whose deposit has cleared (0 when nothing is owed).
const balanceDueOf = (payment) => {
  if (!payment) return 0;
  const d = payment.paymentStatus;
  if (d && d.key === "partial") return Number(d.balance) || 0;
  const info = getPaymentInfo(payment);
  if (info.key !== "partial") return 0;
  return Math.max(0, (Number(payment.amount) || 0) - info.amountPaid);
};

// Firestore Timestamp / {_seconds} / ISO string / Date -> milliseconds (0 when missing).
const toMillis = (val) => {
  if (!val) return 0;
  if (val.toMillis) return val.toMillis();
  if (val._seconds !== undefined) return val._seconds * 1000;
  const t = new Date(val).getTime();
  return Number.isNaN(t) ? 0 : t;
};

// ── Skeleton ──
const Skeleton = () => (
  <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden animate-pulse">
    <div className="flex gap-4 p-5">
      <div className="w-28 h-20 bg-gray-200 rounded-xl flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="h-4 bg-gray-200 rounded w-1/3" />
        <div className="h-3 bg-gray-100 rounded w-1/2" />
        <div className="h-3 bg-gray-100 rounded w-2/3" />
      </div>
    </div>
  </div>
);

// ── Detail row ──
const DR = ({ label, value, mono = false }) =>
  value ? (
    <div>
      <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide">{label}</p>
      <p className={`text-sm text-gray-700 font-medium break-all ${mono ? "font-mono" : ""}`}>{value}</p>
    </div>
  ) : null;

// ── Refund reasons + status config ──
const REFUND_REASONS = [
  "Cancelled trip",
  "Overcharged",
  "Service issue",
  "Duplicate payment",
  "Other",
];

// ── Refund request status config (badge shown once a refund is requested) ──
// Pending / Approved / Refunded only ever show inside the Refunds tab, which already
// says "refund", so they drop the "Refund:" prefix. Rejected / Failed keep it: those
// bookings go back to Upcoming (or sit in History), where a bare "Rejected" or "Failed"
// would be ambiguous.
const REFUND_STATUS_CONFIG = {
  Pending:  { label: "Pending",          bg: "bg-yellow-100", text: "text-yellow-700", border: "border-yellow-300" },
  Approved: { label: "Approved",         bg: "bg-blue-100",   text: "text-blue-700",   border: "border-blue-300" },
  Refunded: { label: "Refunded",         bg: "bg-green-100",  text: "text-green-700",  border: "border-green-300" },
  Rejected: { label: "Refund: Rejected", bg: "bg-red-100",    text: "text-red-600",    border: "border-red-300" },
  Failed:   { label: "Refund: Failed",   bg: "bg-red-100",    text: "text-red-600",    border: "border-red-300" },
};

const RefundStatusBadge = ({ status }) => {
  const cfg = REFUND_STATUS_CONFIG[status];
  if (!cfg) return null;
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
      {cfg.label}
    </span>
  );
};

// ── Cancel / Refund modal ──
// ONE button on the card ("Cancel / Refund") opens this; what it does depends on the booking:
//   mode "refund" -- money was paid: sends a refund request for staff review (48-hour policy applies; the booking is
//                    cancelled once it is approved). Shows what the customer would get back before they confirm.
//   mode "cancel" -- nothing was paid yet (a "to pay" booking): cancels it right away, nothing to refund.
const RefundModal = ({ booking, mode = "refund", onConfirm, onClose, loading }) => {
  const [reason, setReason]   = useState(REFUND_REASONS[0]);
  const [notes, setNotes]     = useState("");
  const [preview, setPreview] = useState(null);   // what a refund would be right now (refund mode only)
  const { amountPaid } = getPaymentInfo(booking.payment);
  const isRefund  = mode === "refund";
  const paymentID = booking.payment?.paymentID;

  useEffect(() => {
    if (!isRefund || !paymentID) return;
    let cancelled = false;
    (async () => {
      try {
        const token = localStorage.getItem("arl_token");
        const res = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/refunds/preview/${paymentID}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const json = await res.json();
        if (!cancelled && res.ok) setPreview(json);
      } catch {
        // non-critical -- the modal still works without the preview
      }
    })();
    return () => { cancelled = true; };
  }, [isRefund, paymentID]);

  const blocked = isRefund && preview && preview.eligible === false;   // the server would reject it anyway

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <h3 className="text-lg font-black text-gray-800 mb-1">Cancel / Refund</h3>
        <p className="text-sm text-gray-500 mb-4">
          {booking.carName}{isRefund ? ` — ${peso(amountPaid)} paid` : " — not paid yet"}
        </p>

        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
          Reason
        </label>
        <select
          className="w-full border border-gray-200 rounded-xl p-3 text-sm mb-3 focus:outline-none focus:ring-2 focus:ring-arl-primary/30"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        >
          {REFUND_REASONS.map((r) => <option key={r} value={r}>{r}</option>)}
        </select>

        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">
          Additional notes (optional)
        </label>
        <textarea
          className="w-full border border-gray-200 rounded-xl p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-arl-primary/30"
          rows={3}
          placeholder={isRefund ? "Tell us more about your refund request..." : "Tell us why you're cancelling..."}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
        />

        {isRefund && preview && preview.eligible && (
          <div className="mt-3 rounded-xl bg-green-50 border border-green-100 px-3 py-2">
            <p className="text-sm font-bold text-green-700">You'll get back {peso(preview.refundAmount)}</p>
            {preview.graceApplied && (
              <p className="text-xs text-green-700/80 mt-0.5">
                Your security deposit is included because you're asking within {preview.graceHours || 2} hours of booking.
              </p>
            )}
            {preview.depositForfeited > 0 && (
              <p className="text-xs text-green-700/80 mt-0.5">
                {peso(preview.depositForfeited)} security deposit is kept because this is under {preview.windowHours || 48} hours before pickup.
              </p>
            )}
          </div>
        )}
        {blocked && preview.message && (
          <p className="mt-3 text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">{preview.message}</p>
        )}

        <p className="text-xs text-gray-400 mt-3">
          {isRefund
            ? `The refund covers what you've paid for this booking (${peso(amountPaid)}, less any deposit kept under the 48-hour policy) and the booking will be cancelled once it's approved. Our team will review it and you'll be notified once it's processed.`
            : "This booking hasn't been paid yet, so nothing will be charged or refunded. It will be cancelled right away."}
        </p>

        <div className="flex gap-3 mt-4">
          <button
            onClick={onClose}
            disabled={loading}
            className="flex-1 py-2.5 rounded-xl border border-gray-200 text-sm font-bold text-gray-600 hover:bg-gray-50 transition">
            Keep booking
          </button>
          <button
            onClick={() => onConfirm(reason, notes)}
            disabled={loading || blocked}
            className="flex-1 py-2.5 rounded-xl bg-arl-cta text-white text-sm font-bold hover:bg-arl-secondary transition disabled:opacity-60">
            {loading ? "Sending…" : isRefund ? "Confirm & Send" : "Cancel booking"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ── Booking card ──
const BookingCard = ({ booking, user, existingRefund, hasActiveRefund = false, refundRejected = false, onRefundRequested, onBookingChanged = () => {} }) => {
  const navigate = useNavigate();
  const [expanded,        setExpanded]        = useState(false);

  const [showRefundModal, setShowRefundModal] = useState(false);
  const [refunding,       setRefunding]       = useState(false);
  const [payingNow,       setPayingNow]       = useState(false);
  const { showToast } = useToast();

  const {
    bookingID, carName, carImage, carBodyType, plateNumber, plateRevealsAt,
    serviceType, duration, startDateTime, endDateTime,
    totalDays, totalFee,
    status, cancellationReason, cancelledAt, cancelledBy,
    modeOfDriving, destination, passengerName, createdAt,
    payment, carID,
    codingWarningCount = 0, codingCities = [],
  } = booking;

  const p = payment || {};


  const handleRebook = () => {
    navigate('/booking', {
      state: {
        carID,
        serviceType,
        duration,
        destination,
        driveType: modeOfDriving === 'With Chauffeur' ? 'chauffeur' : 'self-drive',
        // Start/End date & time are intentionally left out — those should
        // always be freshly chosen, not copied from the old booking.
      },
    });
  };

  // ONE "Cancel / Refund" button, two outcomes by payment state:
  //   paid (upcoming)  -> a refund request for staff review (POST /paymongo/refunds); the booking is cancelled on approval
  //   unpaid (to pay)  -> cancelled straight away (PATCH /bookings/:id/cancel); there is nothing to refund
  const payLower        = String(p.status || "").toLowerCase();
  const isPaidDeposit   = ["paid", "approved"].includes(payLower);
  // A refund request staff already rejected is final -- no button, and the server refuses a new one too.
  const canRefund       = status === "upcoming" && isPaidDeposit && !hasActiveRefund && !refundRejected;
  const canCancelUnpaid = status === "to pay" && !isPaidDeposit && !hasActiveRefund;

  const handleCancelRefund = async (reason, notes) => {
    if (canRefund && !p.paymentID) return;
    setRefunding(true);
    try {
      const token = localStorage.getItem("arl_token");
      if (canRefund) {
        const res   = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/refunds`, {
          method:  "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body:    JSON.stringify({ paymentID: p.paymentID, reason, notes }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to send refund request.");
        setShowRefundModal(false);
        onRefundRequested(); // re-fetch refund requests in the parent
      } else {
        const res   = await fetch(`${process.env.REACT_APP_API_URL}/bookings/${bookingID}/cancel`, {
          method:  "PATCH",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
          body:    JSON.stringify({ reason: notes ? `${reason} — ${notes}` : reason }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to cancel the booking.");
        setShowRefundModal(false);
        showToast("Booking cancelled.");
        onBookingChanged(); // re-fetch the bookings list in the parent
      }
    } catch (err) {
      showToast(err.message);
    } finally {
      setRefunding(false);
    }
  };

  // Deposit already paid, but this is a Partial booking still awaiting its
  // balance? Then "Pay Now" needs to charge the balance instead — this is
  // what decides which one the button below actually does.
  const depositPaid   = p.status === "paid";
  const isPartialPlan = String(p.methodOfPayment || "").toLowerCase() === "partial";
  const balanceDue    = depositPaid && isPartialPlan && p.balanceStatus !== "paid" && !p.balanceCollected;
  // The deposit alone confirms a booking ("upcoming"), but the balance is now REQUIRED and is paid ONLINE
  // before pickup (staff block the pickup until it is settled; collecting it in store is only the exception).
  const canPayBalanceOnline = status === "upcoming" && balanceDue && !hasActiveRefund;
  const balancePending      = canPayBalanceOnline && String(p.balanceStatus || "").toLowerCase() === "pending"; // checkout opened, not finished
  const balanceInfo         = getPaymentInfo(payment);
  const balanceText         = balanceInfo.key === "partial" ? balanceInfo.extra : "";

  // "Pay Now" / "Pay Balance" — for "to pay" bookings only. Same call
  // Booking.jsx's own handlePaymongoCheckout makes right after creating the
  // booking; this is just the version reachable later from My Bookings, for
  // a checkout that got abandoned/closed the first time (deposit), or the
  // separate balance step once the deposit has already cleared.
  const handlePayNow = async () => {
    if (!p.paymentID) return;
    setPayingNow(true);
    try {
      const token = localStorage.getItem("arl_token");
      const res   = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/create-link`, {
        method:  "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body:    JSON.stringify({
          bookingID,
          paymentID:     p.paymentID,
          description:   `ARL Track Booking #${bookingID}${balanceDue ? " (Balance)" : ""}`,
          paymentMethod: p.paymentMethod,
          phase:         balanceDue ? "balance" : "deposit",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to create payment link.");
      // The server found the earlier attempt was actually paid (e.g. the webhook
      // was slow) and settled it — nothing to charge. Show the confirmation page
      // instead of opening a second checkout.
      if (data.alreadyPaid) {
        navigate(`/payment-return?paymentID=${p.paymentID}&bookingID=${bookingID}`);
        return;
      }
      window.location.href = data.checkoutUrl + `?paymentID=${p.paymentID}`;
    } catch (err) {
      showToast(err.message || "Could not connect to PayMongo. Please try again.");
      setPayingNow(false);
    }
  };

  return (
    <>
      {showRefundModal && (
        <RefundModal
          booking={booking}
          mode={canRefund ? "refund" : "cancel"}
          onConfirm={handleCancelRefund}
          onClose={() => setShowRefundModal(false)}
          loading={refunding}
        />
      )}

      <div className={`bg-white rounded-2xl border shadow-sm overflow-hidden hover:shadow-md transition-all duration-300 ${
        status === "cancelled" ? "border-red-100" : status === "completed" ? "border-blue-100" : status === "ongoing" ? "border-purple-100" : status === "to pay" ? "border-yellow-200" : "border-gray-100"
      }`}>

        {/* ── Main row ── */}
        <div className="flex gap-3 sm:gap-4 p-4 sm:p-5">
          {/* Car image */}
          <div className="flex-shrink-0 w-20 h-16 sm:w-28 sm:h-20 rounded-xl overflow-hidden bg-gray-100">
            {carImage
              ? <img src={carImage} alt={carName} className="w-full h-full object-cover"
                  onError={(e) => { e.target.style.display = "none"; e.target.nextSibling.style.display = "flex"; }} />
              : null}
            <div className="w-full h-full items-center justify-center text-2xl sm:text-3xl text-gray-300"
              style={{ display: carImage ? "none" : "flex" }} />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 flex-wrap mb-1">
              <div className="min-w-0">
                <h4 className="font-black text-arl-primary text-base sm:text-lg leading-tight break-words">{carName}</h4>
                {carBodyType && <p className="text-xs text-gray-400 font-semibold uppercase tracking-wide">{carBodyType}</p>}
              </div>
              <div className="flex flex-col items-end gap-1">
                {/* When there's a refund request on file, its own badge
                    (Pending/Approved/Refunded/Rejected/Failed) is more
                    specific than the payment badge, so it takes over instead
                    of showing two badges that both just say "Refunded". */}
                {existingRefund
                  ? <RefundStatusBadge status={existingRefund.status} />
                  : <PaymentStatusBadge payment={payment} />}
              </div>
            </div>

            <div className="space-y-0.5 mb-2">
              <p className="text-xs text-gray-500">
                <span className="font-semibold text-gray-600">Service:</span> {serviceType || "—"}
              </p>
              {plateNumber ? (
                <p className="text-xs text-gray-500">
                  <span className="font-semibold text-gray-600">Plate no.:</span>{" "}
                  <span className="font-mono font-bold text-gray-800 tracking-wider">{plateNumber}</span>
                </p>
              ) : plateRevealsAt ? (
                <p className="text-xs text-gray-400">Plate no. shown {fmtDT(plateRevealsAt)}</p>
              ) : null}
              <p className="text-xs text-gray-500">
                <span className="font-semibold text-gray-600">Start:</span> {fmtDT(startDateTime)}
              </p>
              <p className="text-xs text-orange-700 font-bold bg-orange-50 border border-orange-200 rounded-md px-1.5 py-0.5 inline-block">
                End: {fmtDT(endDateTime)}
              </p>
              <p className="text-xs text-gray-400">
                <span className="font-semibold text-gray-500">Booked on:</span> {fmtDT(createdAt)}
              </p>
              {existingRefund?.createdAt && (
                <p className="text-xs text-gray-400">
                  <span className="font-semibold text-gray-500">Refund requested:</span> {fmtDT(existingRefund.createdAt)}
                </p>
              )}
              {!existingRefund && status === "cancelled" && cancelledAt && (
                <p className="text-xs text-gray-400">
                  <span className="font-semibold text-gray-500">{cancelledBy === "customer" ? "Cancellation requested:" : "Cancelled on:"}</span> {fmtDT(cancelledAt)}
                </p>
              )}
              {/* Number Coding heads-up: only while the trip is still ahead of / underway. The full schedule is on Details. */}
              {codingWarningCount > 0 && ["to pay", "upcoming", "ongoing"].includes(status) && (
                <button
                  type="button"
                  onClick={() => navigate(`/booking/${bookingID}/details`)}
                  title={codingCities.length ? `Coding in: ${codingCities.join(", ")}` : "Number coding applies to this vehicle"}
                  className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 hover:bg-amber-100 rounded-full px-2 py-0.5 transition">
                  ⚠ {codingWarningCount} coding restriction{codingWarningCount === 1 ? "" : "s"}
                </button>
              )}
              {cancellationReason && (
                <p className="text-xs text-red-500 font-medium mt-1">
                  Reason: {cancellationReason}
                </p>
              )}
              {/* Admin's reason for rejecting/failing the refund — was
                  already being captured and saved (rejectReason on the
                  refundRequests doc, set via the admin Reject action) but
                  never surfaced anywhere in the customer app before. Styled
                  as a small callout instead of loose text so it reads as a
                  distinct note rather than crowding the badge above. */}
              {existingRefund?.status === "Rejected" && existingRefund?.rejectReason && (
                <div className="mt-1.5 flex items-start gap-1.5 bg-red-50 border border-red-100 rounded-lg px-2.5 py-1.5">
                  <span className="text-red-400 text-xs leading-none mt-0.5">✕</span>
                  <p className="text-xs text-red-600 leading-snug">
                    <span className="font-semibold">Refund rejected:</span> {existingRefund.rejectReason}
                  </p>
                </div>
              )}
              {refundRejected && ["upcoming", "ongoing"].includes(status) && (
                <p className="mt-1.5 text-xs text-gray-600 leading-snug">
                  <span className="font-semibold">Your booking will continue as scheduled.</span>{" "}
                  This refund can't be requested again — please contact support if you need help.
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2.5">
              <div className="flex items-center gap-3">
                {discountPriceOff(p) > 0 ? (
                  <span className="flex items-baseline gap-2 flex-wrap">
                    <span className="text-lg sm:text-xl font-black text-arl-cta">{peso((p.amount || totalFee) - discountPriceOff(p))}</span>
                    <span className="text-sm text-gray-400 line-through">{peso(p.amount || totalFee)}</span>
                  </span>
                ) : (
                  <span className="text-lg sm:text-xl font-black text-arl-cta">{peso(p.amount || totalFee)}</span>
                )}
                <span className="text-xs text-gray-400">{totalDays} day(s)</span>
                <DiscountHeldPill discount={p.discount} />
              </div>

              {canPayBalanceOnline && (
                <div className={`rounded-lg border px-2.5 py-1.5 ${balancePending ? "bg-amber-50 border-amber-200" : "bg-red-50 border-red-200"}`}>
                  <p className={`text-xs font-bold ${balancePending ? "text-amber-700" : "text-red-700"}`}>
                    {balancePending ? "Balance payment pending" : "Balance payment required"}{balanceText ? ` — ${balanceText}` : ""}
                  </p>
                  <p className="text-[11px] text-gray-500 mt-0.5">
                    {balancePending
                      ? "You started paying online but it isn't finished yet. Finish it before pickup."
                      : "Pay the remaining balance online before pickup — we can't release the vehicle until it's paid."}
                  </p>
                </div>
              )}

              <div className="flex items-center gap-2 flex-wrap">
                {/* Pay Now / Pay Balance — the primary action for a "to
                    pay" booking. Re-opens PayMongo checkout for whichever
                    phase is still outstanding (deposit, or the balance for
                    a Partial booking whose deposit already cleared) — same
                    call Booking.jsx makes right after creating it, for
                    when the customer closed/abandoned that checkout tab. */}
                {status === "to pay" && (
                  <button
                    onClick={handlePayNow}
                    disabled={payingNow}
                    className="text-xs font-bold text-white bg-arl-cta hover:bg-opacity-90 disabled:opacity-60 px-3 py-1.5 rounded-lg transition">
                    {payingNow ? "Redirecting…" : balanceDue ? "Pay Balance" : "Pay Now"}
                  </button>
                )}

                {/* REQUIRED: the remaining balance is paid online before pickup. Only for a confirmed
                    (upcoming) Partial booking whose balance is still open. */}
                {canPayBalanceOnline && (
                  <button
                    onClick={handlePayNow}
                    disabled={payingNow}
                    className="text-xs font-bold text-white bg-red-600 hover:bg-red-700 disabled:opacity-60 px-3 py-1.5 rounded-lg transition">
                    {payingNow ? "Redirecting…" : balancePending ? "Finish balance payment" : "Pay balance now"}
                  </button>
                )}

                {/* Cancel button removed from "To Pay" too — Request Refund
                    (admin review) is now the only way to back out of a
                    booking, at any stage, paid or not yet paid. */}

                {/* Cancel button removed — Request Refund is now the only
                    way to back out of an upcoming booking. Cancelling
                    directly used to skip the admin review a refund goes
                    through, which didn't make sense once refunds became
                    the standard path. */}

                {/* Cancel / Refund — one button. Paid "upcoming" bookings send a refund request;
                    an unpaid "to pay" booking is cancelled directly (see handleCancelRefund). Paid-booking notes: */}
                {/* Request Refund — "upcoming" (fully paid) bookings only.
                    A "to pay" booking never qualifies anymore, even once
                    its deposit has cleared (Partial) — see requestRefund()
                    in controllers/paymongo/paymongo.controller.js: a booking that isn't
                    fully confirmed yet isn't something to refund, it's
                    something to finish paying or to cancel outright. No
                    active refund request already in flight. A past
                    Failed request (the refund itself errored) can be
                    retried, but a Rejected one is final: no button. */}
                { (canRefund || canCancelUnpaid) && (
                  <button
                    onClick={() => setShowRefundModal(true)}
                    className="text-xs font-bold text-orange-600 border border-orange-200 hover:bg-orange-50 px-3 py-1.5 rounded-lg transition">
                    Cancel / Refund
                  </button>
                )}

                {/* Booking Details — pins + trip info for every booking */}
                <button
                  onClick={() => navigate(`/booking/${bookingID}/details`)}
                  className="text-xs font-bold text-purple-600 border border-purple-200 hover:bg-purple-50 px-3 py-1.5 rounded-lg transition">
                  Details
                </button>

                {/* Rebook — for cancelled and completed */}
                {(status === "cancelled" || status === "completed") && (
                  <button
                    onClick={handleRebook}
                    className="text-xs font-bold text-arl-secondary border border-arl-secondary/30 hover:bg-arl-secondary/10 px-3 py-1.5 rounded-lg transition">
                    Rebook
                  </button>
                )}

                <button onClick={() => setExpanded(!expanded)}
                  className="text-xs font-bold text-arl-secondary hover:text-arl-primary transition flex items-center gap-1">
                  {expanded ? "Hide overview ▲" : "View overview ▼"}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ── Expanded details ── */}
        {expanded && (
          <div className="border-t border-gray-100">
            <div className="px-5 py-4 bg-gray-50">
              <p className="text-xs font-black text-arl-primary uppercase tracking-widest mb-3">Booking Details</p>
              <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-3">
                <DR label="Booking ID"  value={bookingID} mono />
                <DR label="Booked On"   value={fmtDT(createdAt)} />
                <DR label="Start"       value={fmtDT(startDateTime)} />
                <DR label="End"         value={fmtDT(endDateTime)} />
                <DR label="Duration"    value={duration ? `${duration}/day` : null} />
                <DR label="Days"        value={`${totalDays} day(s)`} />
                <DR label="Mode"        value={modeOfDriving} />
                <DR label="Destination" value={destination} />
                <DR label="Passenger"   value={passengerName} />
                <DR label="Service"     value={serviceType} />
              </div>
            </div>

            {payment ? (
              <div className="px-5 py-4 bg-blue-50/50 border-t border-blue-100">
                <p className="text-xs font-black text-arl-primary uppercase tracking-widest mb-3">Payment Details</p>
                <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-3 mb-4">
                  <DR label="Payment ID"        value={p.paymentID} mono />
                  <DR label="Total Amount"      value={
                    discountPriceOff(p) > 0
                      ? <span className="flex items-baseline gap-1.5 flex-wrap">
                          <span>{peso((p.amount || 0) - discountPriceOff(p))}</span>
                          <span className="text-xs text-gray-400 line-through font-normal">{peso(p.amount)}</span>
                        </span>
                      : peso(p.amount)
                  } />
                  <DR label="Rental Fee"        value={peso(p.rentalFee)} />
                  <DR label="Service Fee"       value={peso(p.serviceFee)} />
                  <DR label="Gateway Fee"       value={peso(p.gatewayFee)} />
                  <DR label="Extra Fee"         value={peso(p.extraFee)} />
                  <DR label="Drivers Fee"       value={p.driversFee ? peso(p.driversFee) : null} />
                  <DR label="Security Deposit (refundable)" value={p.securityDeposit ? peso(p.securityDeposit) : null} />
                  <DR label="Payment Method"    value={p.methodOfPayment || p.paymentMethod} />
                  <DR label="Reference No."     value={p.referenceNumber} mono />
                  <DR label="Payment Status"    value={p.status} />
                </div>
                {/* An older backend sends no `discount`: show the old single figure. */}
                {p.discount
                  ? <DiscountSummary discount={p.discount} className="mb-4" />
                  : p.discountAmount > 0 && <DiscountSummary discount={{ status: "legacy", total: p.discountAmount }} className="mb-4" />}
                {p.proofUrl && (
                  <div>
                    <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Proof of Payment</p>
                    <img src={p.proofUrl} alt="Payment proof"
                      className="max-h-48 w-auto rounded-xl border border-gray-200 object-contain bg-white"
                      onError={(e) => { e.target.style.display = "none"; }}
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="px-5 py-4 bg-gray-50 border-t border-gray-100">
                <p className="text-xs text-gray-400">No payment record found for this booking.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

// ── Sub-tabs (pill row) used inside Refunds and History ──
const SubTabs = ({ tabs, active, onChange, loading }) => (
  <div className="flex gap-2 mb-4 flex-wrap">
    {tabs.map(({ key, label, count }) => (
      <button key={key} onClick={() => onChange(key)}
        className={`px-3.5 py-1.5 rounded-full text-xs font-bold border transition ${
          active === key
            ? "bg-arl-primary text-white border-arl-primary"
            : "bg-white text-gray-500 border-gray-200 hover:border-arl-primary/40 hover:text-arl-primary"
        }`}>
        {label} <span className="opacity-70">{loading ? "…" : count}</span>
      </button>
    ))}
  </div>
);

// ── To Pay: a confirmed Partial booking that still owes its balance ──
// One small card: how much is pending, why (partial payment), Pay now + View booking.
const PartialBalanceCard = ({ booking }) => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [paying, setPaying] = useState(false);
  const p = booking.payment || {};
  const balance = balanceDueOf(p);
  const { amountPaid } = getPaymentInfo(p);
  const pending = String(p.balanceStatus || "").toLowerCase() === "pending"; // checkout opened, not finished

  const handlePay = async () => {
    if (!p.paymentID) { navigate(`/booking/${booking.bookingID}/details`); return; }
    setPaying(true);
    try {
      const token = localStorage.getItem("arl_token");
      const res = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/create-link`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          bookingID: booking.bookingID,
          paymentID: p.paymentID,
          description: `ARL Track Booking #${booking.bookingID} (Balance)`,
          paymentMethod: p.paymentMethod,
          phase: "balance",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to create payment link.");
      if (data.alreadyPaid) {
        navigate(`/payment-return?paymentID=${p.paymentID}&bookingID=${booking.bookingID}`);
        return;
      }
      window.location.href = data.checkoutUrl + `?paymentID=${p.paymentID}`;
    } catch (err) {
      showToast(err.message || "Could not connect to PayMongo. Please try again.");
      setPaying(false);
    }
  };

  return (
    <div className="rounded-2xl bg-orange-50 border border-orange-200 px-4 py-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs text-gray-500 truncate">
            {booking.carName} · Booking #{String(booking.bookingID).slice(-6).toUpperCase()}
          </p>
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-base font-black text-orange-700">{peso(balance)} pending</p>
            <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border bg-orange-100 text-orange-700 border-orange-300">
              Partial payment
            </span>
            {pending && (
              <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border bg-amber-100 text-amber-700 border-amber-300">
                Payment pending
              </span>
            )}
          </div>
          <p className="text-[11px] text-gray-500 mt-0.5">
            You've paid {peso(amountPaid)} so far. The remaining balance is due before pickup.
          </p>
        </div>
        <div className="flex flex-col gap-1.5 flex-shrink-0">
          <button onClick={handlePay} disabled={paying}
            className="whitespace-nowrap rounded-xl bg-red-600 hover:bg-red-700 disabled:opacity-60 text-white text-xs font-bold px-3 py-2 transition-colors">
            {paying ? "Redirecting…" : pending ? "Finish payment" : "Pay now"}
          </button>
          <button onClick={() => navigate(`/booking/${booking.bookingID}/details`)}
            className="whitespace-nowrap rounded-xl border border-purple-200 text-purple-600 hover:bg-purple-50 text-xs font-bold px-3 py-2 transition">
            View booking
          </button>
        </div>
      </div>
    </div>
  );
};

// ── Empty state ──
// A live calendar icon for the "upcoming" empty state — replaces the calendar
// emoji, which renders with a hard-coded, platform-specific date baked
// into the glyph itself (fixed at "17" on this Android build, something
// else elsewhere) rather than the actual current date, which read as a
// stuck/wrong date on-screen.
const LiveCalendarIcon = () => {
  const now   = new Date();
  const month = now.toLocaleDateString("en-US", { month: "short" }).toUpperCase();
  const day   = now.getDate();
  return (
    <div className="inline-flex flex-col w-16 rounded-lg overflow-hidden border border-gray-200 shadow-sm mx-auto">
      <div className="bg-red-500 text-white text-[10px] font-bold tracking-wide text-center py-0.5">
        {month}
      </div>
      <div className="bg-white text-gray-800 text-2xl font-black text-center py-1.5">
        {day}
      </div>
    </div>
  );
};

const EMPTY_STATE_COPY = {
  toPay:    { title: "Nothing to pay",         body: "Unpaid bookings awaiting payment will show up here." },
  upcoming: { title: "No upcoming bookings",  body: "Book a ride to see it here." },
  ongoing:  { title: "No trip in progress",    body: "Your active trip will show up here once it starts." },
  refunds:  { title: "No refund requests",     body: "Bookings you've requested a refund for will show up here." },
  history:  { title: "No booking history yet", body: "Your completed and cancelled bookings will appear here." },
  refunds_pending:  { title: "No pending refunds",  body: "Refund requests waiting for staff review will show up here." },
  refunds_approved: { title: "No approved refunds", body: "Approved refunds that are still being sent back to you will show up here." },
  refunds_refunded: { title: "No refunded bookings", body: "Refunds that have been completed will show up here." },
  history_completed: { title: "No completed trips", body: "Trips you've finished will show up here." },
  history_cancelled: { title: "No cancelled bookings", body: "Bookings that were cancelled will show up here." },
};

const EmptyState = ({ tab }) => {
  const { title, body } = EMPTY_STATE_COPY[tab] || EMPTY_STATE_COPY.upcoming;
  return (
    <div className="text-center py-20">
      <div className="mb-4">
        {tab === "upcoming" && <LiveCalendarIcon />}
      </div>
      <p className="text-gray-500 font-bold text-lg">{title}</p>
      <p className="text-gray-400 text-sm mt-1">{body}</p>
    </div>
  );
};

// ── My Bookings page ──
const MyBookings = ({ user }) => {
  const navigate   = useNavigate();
  const [bookings,  setBookings]  = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState("");
  // ?tab=to-pay lets PayMongo's "cancel" link (and notifications) land straight
  // on the unpaid booking with its Pay Now button.
  const [activeTab, setActiveTab] = useState(() => {
    try {
      const t = new URLSearchParams(window.location.search).get("tab");
      const map = { "to-pay": "toPay", toPay: "toPay", upcoming: "upcoming", ongoing: "ongoing", refunds: "refunds", history: "history" };
      return map[t] || "upcoming";
    } catch { return "upcoming"; }
  });

  const [refundRequests, setRefundRequests] = useState([]);
  const [refundSub,  setRefundSub]  = useState("pending");    // pending | approved | refunded
  const [sortBy,     setSortBy]     = useState("recent");     // recent | oldest | highest | lowest (amount: Refunds only)
  const [historySub, setHistorySub] = useState("completed");  // completed | cancelled

  useEffect(() => {
    if (!user?.userID) { navigate("/"); return; }
    fetchBookings();
    fetchRefundRequests();
    fetchOutstandingBalance();
  // The fetch functions are re-created every render; this only needs to re-run when the user changes.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const fetchBookings = async () => {
    setLoading(true);
    setError("");
    try {
      const token = localStorage.getItem("arl_token");
      const res   = await fetch(`${process.env.REACT_APP_API_URL}/bookings/user/${user.userID}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch bookings.");
      const data = await res.json();
      setBookings(data);
    } catch (err) {
      setError("Could not load bookings. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const fetchRefundRequests = async () => {
    try {
      const token = localStorage.getItem("arl_token");
      const res   = await fetch(`${process.env.REACT_APP_API_URL}/paymongo/refunds/mine`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) setRefundRequests(data.data || []);
    } catch {
      // non-critical — refund badges/buttons just won't reflect the latest state
    }
  };

  // Any confirmed-but-unpaid penalty balance across this customer's past
  // bookings, mirrored onto the user doc by admin-backend's
  // penalty.service.js whenever it changes. Shown as a single account-
  // level banner here (not fetched per-booking-card, which would be an
  // N+1 request for a list this size) — createBooking already blocks new
  // bookings while this is > 0, so the banner is telling the customer
  // why, not just informing them.
  const [outstandingBalance, setOutstandingBalance] = useState(0);
  // [{ bookingID, amount, coveredByDeposit, onlineDue, fee, total, pending }]: amount = every unpaid penalty; a held
  // deposit pays coveredByDeposit of it (no fee); onlineDue is paid online, with fee on top (total = onlineDue + fee).
  const [outstandingBookings, setOutstandingBookings] = useState([]);
  const fetchOutstandingBalance = async () => {
    try {
      const token = localStorage.getItem("arl_token");
      const res   = await fetch(`${process.env.REACT_APP_API_URL}/user/profile/${user.userID}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setOutstandingBalance(data.outstandingPenaltyBalance || 0);
        setOutstandingBookings(data.outstandingPenaltyBookings || []);
      }
    } catch {
      // non-critical — the banner just won't show; createBooking still enforces the block server-side
    }
  };

  // Only these statuses count as "there's already an active request".
  // Failed lets the customer try again; Rejected is final (see hasRejectedRefund).
  const findActiveRefund = (paymentID) =>
    refundRequests.find((r) => r.paymentID === paymentID && ["Pending", "Approved", "Refunded"].includes(r.status));

  // Any refund request at all, regardless of status — used for the Refunds
  // tab (a true history/tracking view) and for the status badge, which
  // should still show e.g. "Rejected" even though that status doesn't
  // block a retry.
  // A request staff rejected can't be filed again for that payment.
  const hasRejectedRefund = (paymentID) =>
    refundRequests.some((r) => r.paymentID === paymentID && r.status === "Rejected");

  const findAnyRefund = (paymentID) =>
    refundRequests.find((r) => r.paymentID === paymentID);

  // Whether a booking has an active or completed refund story right now
  // (Pending/Approved/Refunded, or a payment already marked "refunded"
  // outright). This is the single source of truth for both tabs below —
  // Upcoming and Refunds are meant to be mutually exclusive:
  //   - true  → belongs in Refunds, not Upcoming (something's actually
  //             in motion or done; that trip isn't happening as planned).
  //   - false → belongs in Upcoming, not Refunds. This also covers a
  //             booking whose ONLY refund history is Rejected/Failed —
  //             nothing about the booking actually changed, so it goes
  //             back to being a normal upcoming trip and drops out of
  //             Refunds entirely, until/unless a new request is filed
  //             (which flips this back to true and moves it over again).
  const hasActiveRefundStory = (b) =>
    (b.payment?.status || "").toLowerCase() === "refunded" ||
    !!(b.payment?.paymentID && findActiveRefund(b.payment.paymentID));
  const toPay     = bookings.filter(b => b.status === "to pay");
  // Unpaid penalties belong under To Pay too (one entry per booking that owes).
  // Falls back to 1 if the balance is > 0 but the per-booking list is empty.
  const penaltyCount = outstandingBalance > 0 ? Math.max(outstandingBookings.length, 1) : 0;
  const upcoming  = bookings.filter(b => b.status === "upcoming" && !hasActiveRefundStory(b));
  const ongoing   = bookings.filter(b => b.status === "ongoing");
  const refunded  = bookings.filter(hasActiveRefundStory);
  // History and Refunds never overlap: a booking with a refund story lives only under Refunds.
  const history   = bookings.filter(b => ["cancelled", "completed"].includes(b.status) && !hasActiveRefundStory(b));

  // Confirmed Partial bookings that still owe their balance — shown in To Pay as a simple reminder card
  // (they also stay in Upcoming, since the deposit already confirmed the trip).
  const partialDue = bookings.filter(b =>
    b.status === "upcoming" && !hasActiveRefundStory(b) && balanceDueOf(b.payment) > 0);
  const toPayExtras = penaltyCount + partialDue.length;

  // ── Refunds: Pending / Approved / Refunded ──
  const refundOf       = (b) => (b.payment?.paymentID ? findActiveRefund(b.payment.paymentID) : null);
  const refundStatusOf = (b) => refundOf(b)?.status || ((b.payment?.status || "").toLowerCase() === "refunded" ? "Refunded" : "");
  const refundGroup    = (key) => refunded.filter(b => refundStatusOf(b).toLowerCase() === key);
  const refundPending  = refundGroup("pending");
  const refundApproved = refundGroup("approved");
  const refundDone     = refundGroup("refunded");
  const refundAmountOf = (b) => { const r = refundOf(b); return Number(r?.amount ?? r?.toRefundAmount ?? 0) || 0; };
  const refundDateOf   = (b) => { const r = refundOf(b); return toMillis(r?.createdAt) || toMillis(r?.refundedAt); }; // when it was requested
  // History: a cancelled booking sorts by when it was cancelled, a completed one by when the trip ended.
  const historyDateOf  = (b) => b.status === "cancelled"
    ? (toMillis(b.cancelledAt) || toMillis(b.endDateTime))
    : (toMillis(b.endDateTime) || toMillis(b.startDateTime));
  // Amount sorting only makes sense for refunds; History falls back to most recent.
  const effectiveSort = activeTab === "history" && (sortBy === "highest" || sortBy === "lowest") ? "recent" : sortBy;
  const sortList = (list, dateOf, amountOf = () => 0) => [...list].sort((a, b) =>
    effectiveSort === "oldest"  ? dateOf(a) - dateOf(b) :
    effectiveSort === "highest" ? amountOf(b) - amountOf(a) :
    effectiveSort === "lowest"  ? amountOf(a) - amountOf(b) :
    dateOf(b) - dateOf(a));

  // ── History: Completed / Cancelled ──
  const historyCompleted = history.filter(b => b.status === "completed");
  const historyCancelled = history.filter(b => b.status === "cancelled");

  const displayed =
    activeTab === "toPay"    ? toPay    :
    activeTab === "upcoming" ? upcoming :
    activeTab === "ongoing"  ? ongoing  :
    activeTab === "refunds"  ? sortList(refundSub === "pending" ? refundPending : refundSub === "approved" ? refundApproved : refundDone, refundDateOf, refundAmountOf) :
    sortList(historySub === "completed" ? historyCompleted : historyCancelled, historyDateOf);
  const emptyKey =
    activeTab === "refunds" ? `refunds_${refundSub}` :
    activeTab === "history" ? `history_${historySub}` :
    activeTab;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-16">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">

        <div className="mb-8">
          <h1 className="text-3xl font-black text-arl-primary tracking-tight">My Bookings</h1>
          <p className="text-gray-500 text-sm mt-1">Track all your rides and payment details</p>
        </div>

        <div className="flex overflow-x-auto scrollbar-hide bg-white rounded-2xl border border-gray-100 shadow-sm p-1.5 mb-6 gap-1 -mx-1 px-1 sm:mx-0">
          {[
            { key: "toPay",    label: "To Pay",   count: toPay.length + toPayExtras },
            { key: "upcoming", label: "Upcoming", count: upcoming.length },
            { key: "ongoing",  label: "Ongoing",  count: ongoing.length },
            { key: "refunds",  label: "Refunds",  count: refunded.length },
            { key: "history",  label: "History",  count: history.length },
          ].map(({ key, label, count }) => (
            <button key={key} onClick={() => setActiveTab(key)}
              className={`flex-1 shrink-0 flex items-center justify-center gap-1.5 whitespace-nowrap py-2.5 px-3 sm:px-4 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === key ? "bg-arl-primary text-white shadow" : "text-gray-500 hover:text-arl-primary hover:bg-gray-50"
              }`}>
              <span>{label}</span>
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] sm:text-xs font-black ${
                activeTab === key ? "bg-white/20 text-white" : "bg-gray-100 text-gray-500"
              }`}>
                {loading ? "…" : count}
              </span>
            </button>
          ))}
        </div>

        <p className="text-xs text-gray-400 mb-4">
          {activeTab === "toPay"
            ? "To Pay — Complete payment within 12 hours or the booking is auto-cancelled."
            : activeTab === "upcoming"
            ? "Upcoming — You can cancel bookings before they start."
            : activeTab === "ongoing"
            ? "Your trip is currently active."
            : activeTab === "refunds"
            ? "Bookings with an active or past refund request."
            : "Completed & Cancelled — Use Rebook to book the same car again."}
        </p>

        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 text-red-600 text-sm rounded-xl px-4 py-3">
            {error}
          </div>
        )}

        {activeTab === "refunds" && (
          <>
            <SubTabs loading={loading} active={refundSub} onChange={setRefundSub} tabs={[
              { key: "pending",  label: "Pending",  count: refundPending.length },
              { key: "approved", label: "Approved", count: refundApproved.length },
              { key: "refunded", label: "Refunded", count: refundDone.length },
            ]} />
          </>
        )}
        {activeTab === "history" && (
          <SubTabs loading={loading} active={historySub} onChange={setHistorySub} tabs={[
            { key: "completed", label: "Completed", count: historyCompleted.length },
            { key: "cancelled", label: "Cancelled", count: historyCancelled.length },
          ]} />
        )}
        {(activeTab === "refunds" || activeTab === "history") && displayed.length > 1 && (
          <div className="flex items-center gap-2 mb-4">
            <label className="text-xs font-semibold text-gray-500">Sort by</label>
            <select value={effectiveSort} onChange={(e) => setSortBy(e.target.value)}
              className="border border-gray-200 rounded-lg bg-white px-2.5 py-1.5 text-xs font-semibold text-gray-600 focus:outline-none focus:ring-2 focus:ring-arl-primary/30">
              <option value="recent">Most recent</option>
              <option value="oldest">Oldest</option>
              {activeTab === "refunds" && <option value="highest">Highest amount</option>}
              {activeTab === "refunds" && <option value="lowest">Lowest amount</option>}
            </select>
          </div>
        )}

        <div className="space-y-4">
          {activeTab === "toPay" && penaltyCount > 0 && (
            <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-4">
              <p className="text-sm font-bold text-red-700">
                Unpaid penalty: ₱{outstandingBalance.toLocaleString()}
              </p>
              <p className="text-xs text-red-500 mt-0.5">
                {outstandingBookings.length > 0 && outstandingBookings.every((b) => (b.onlineDue ?? b.amount) <= 0)
                  ? "Your security deposit pays these when the booking is settled, so there is nothing to pay online. You can't make a new booking until then."
                  : "Penalties are paid online (GCash, Maya or QR Ph) — open the booking and tap Pay. You can't make a new booking until it is paid."}
              </p>
              {outstandingBookings.length > 0 && (
                <div className="mt-3 flex flex-col gap-2">
                  {outstandingBookings.map((b) => {
                    // Older backends send only `amount`: everything is then online with no fee.
                    const due = b.onlineDue ?? b.amount;
                    const fee = b.fee || 0;
                    const covered = b.coveredByDeposit || 0;
                    const coveredCredit = b.coveredByCredit || 0;
                    const total = b.total ?? b.amount;
                    return (
                      <div key={b.bookingID} className="flex items-center justify-between gap-3 bg-white/70 rounded-xl px-3 py-2">
                        <div className="min-w-0">
                          <p className="text-xs text-gray-500 truncate">Booking #{String(b.bookingID).slice(-6).toUpperCase()}</p>
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-bold text-red-700">₱{Number(due > 0 ? total : b.amount).toLocaleString()}</p>
                            <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border bg-red-100 text-red-700 border-red-300">Penalty</span>
                            {due > 0 ? (
                              <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                b.pending ? "bg-amber-100 text-amber-700 border-amber-300" : "bg-red-100 text-red-700 border-red-300"
                              }`}>
                                {b.pending ? "Payment pending" : "Payment required"}
                              </span>
                            ) : (
                              <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border bg-blue-100 text-blue-700 border-blue-300">
                                {coveredCredit > 0 ? (covered > 0 ? "Covered by deposit & discount credit" : "Covered by discount credit") : "Covered by deposit"}
                              </span>
                            )}
                          </div>
                          {due > 0 && fee > 0 && (
                            <p className="text-[11px] text-gray-500">₱{Number(due).toLocaleString()} penalty + ₱{Number(fee).toLocaleString()} online payment fee</p>
                          )}
                          {covered > 0 && (
                            <p className="text-[11px] text-gray-500">₱{Number(covered).toLocaleString()} covered by your deposit (no fee)</p>
                          )}
                          {coveredCredit > 0 && (
                            <p className="text-[11px] text-gray-500">₱{Number(coveredCredit).toLocaleString()} covered by your discount credit (no fee)</p>
                          )}
                        </div>
                        <button
                          onClick={() => navigate(`/booking/${b.bookingID}/details`)}
                          className="whitespace-nowrap rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-3 py-2 transition-colors"
                        >
                          {due <= 0 ? "View" : b.pending ? "Finish payment" : "Pay now"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
          {activeTab === "toPay" && !loading && partialDue.map(b => (
            <PartialBalanceCard key={`partial-${b.bookingID}`} booking={b} />
          ))}
          {loading
            ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} />)
            : displayed.length > 0
            ? displayed.map(b => (
                <BookingCard
                  key={b.bookingID}
                  booking={b}
                  user={user}
                  existingRefund={b.payment?.paymentID ? findAnyRefund(b.payment.paymentID) : null}
                  hasActiveRefund={!!(b.payment?.paymentID && findActiveRefund(b.payment.paymentID))}
                  refundRejected={!!(b.payment?.paymentID && hasRejectedRefund(b.payment.paymentID))}
                  onRefundRequested={fetchRefundRequests}
                  onBookingChanged={fetchBookings}
                />
              ))
            : (activeTab === "toPay" && toPayExtras > 0) ? null : <EmptyState tab={emptyKey} />
          }
        </div>

        {!loading && (
          <div className="text-center mt-8">
            <button onClick={fetchBookings}
              className="text-sm text-arl-secondary hover:text-arl-primary font-semibold transition">
              Refresh
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyBookings;